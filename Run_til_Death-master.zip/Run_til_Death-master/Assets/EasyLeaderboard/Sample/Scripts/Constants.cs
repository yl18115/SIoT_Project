﻿public class Constants
{
    public const string LeaderboardName = "Default";
}