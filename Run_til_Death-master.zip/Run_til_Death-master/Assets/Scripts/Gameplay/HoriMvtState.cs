﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// An enumeration of the horizontal movement states
public enum HoriMvtState {
    Normal,
    Buffed
}